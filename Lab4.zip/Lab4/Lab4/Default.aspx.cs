﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab4
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void Button1_Click(object sender, EventArgs e)
        {
            output.Text = "";
            comment.Text = "";
            double inp = 0;
            double oup = 0;
            try
            {
                inp = double.Parse(input.Text);
            }
            catch (Exception ex)
            {
                comment.Text = "Error! value must be numerical";
                input.Text = "";
                return;
            }
            if (inp < 0)
            {
                comment.Text = "Error! value must be positive";
                return;
            }
            if (from_units.SelectedValue == to_units.SelectedValue)
            {
                comment.Text = "Error! converting to same unit";
                return;
            }
            double mul = Convert.ToDouble(from_units.SelectedValue);
            double div = Convert.ToDouble(to_units.SelectedValue);
            oup = (inp * mul)/div;
            output.Text = oup.ToString();
        }
    }
}