﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Lab4
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Vote_op(object sender, EventArgs e)
        {
            error.Text = "";
            int item_count = 0; 
            if (RList.SelectedItem == null)
            {
                error.Text = "Please Select At Least One Restaurant";
                return;
            }
            for (int i = 0; i < RList.Items.Count; i++)
            {
                if (RList.Items[i].Selected != false)
                {
                    item_count++;
                }
            }
            if (item_count > 2)
            {
                error.Text = "Please Select Less Than 3.";
                return; 
            }
            
            const string connString = @"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Lab6DB.mdf;Integrated Security = True";
            SqlConnection sql_conn = new SqlConnection(connString);
            sql_conn.Open();
            for (int i = 0; i < RList.Items.Count; i++)
            {
                if (RList.Items[i].Selected != false)
                {
                    SqlCommand cmd = new SqlCommand("UPDATE Conversions SET count=count+1 WHERE name='"+RList.Items[i]+"'", sql_conn);
                    cmd.ExecuteNonQuery();
                }
            }
            sql_conn.Close();
            RList.ClearSelection();
            Response.Redirect("Vote.aspx");
        }
    }
}