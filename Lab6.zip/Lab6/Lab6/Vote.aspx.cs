﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;

namespace Lab4
{
    public partial class Vote : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataView dv = (DataView)VoteDB.Select(DataSourceSelectArguments.Empty);
            TableHeaderRow header = new TableHeaderRow();
            TableCell h1 = new TableCell();
            h1.Text = "Restaurants";
            TableCell h2 = new TableCell();
            h2.Text = "Votes";
            header.Cells.Add(h1);
            header.Cells.Add(h2);
            result.Rows.Add(header);

            foreach (DataRow dr in dv.Table.Rows)
            {
                TableRow r = new TableRow();
                TableCell name = new TableCell();
                TableCell numvote = new TableCell();

                name.BorderWidth = 2;
                name.BorderColor = Color.DarkGreen;
                name.Width = 120;
                name.Height = 50;

                numvote.BorderWidth = 2;
                numvote.BorderColor = Color.DarkGreen;
                numvote.Width = 50;
                numvote.Height = 50;


                int votes = Convert.ToInt16(dr["count"].ToString());
                name.Text = dr["name"].ToString();
                numvote.Text = votes.ToString();

                r.Cells.Add(name);
                r.Cells.Add(numvote);
                result.Rows.Add(r);
            }
        }
    }
}