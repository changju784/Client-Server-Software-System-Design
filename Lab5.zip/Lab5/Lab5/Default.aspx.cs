﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab5
{
    public partial class Default : System.Web.UI.Page
    {
        List<string>list = new List<string>();

        protected void Page_Load(object sender, EventArgs e)
        {
            bl1.Visible = false;
        }
        public void Button1_Click(object sender, EventArgs e)
        {
            comment.Text = "";
            if (Button1.Text == "Add to Cart")
            {
                if (lb1.SelectedItem == null)
                {
                    comment.Text = "Please make a selection."; 
                }
                else
                {
                    comment.Text = "Added.";
                    //list.Add(lb1.SelectedItem.ToString());
                    bl1.Items.Add(lb1.SelectedItem);
                    Button1.Text = "Continue Shopping";
                }
            }
            else if (Button1.Text == "Continue Shopping")
            {
                Button1.Text = "Add to Cart";
            }
            lb1.ClearSelection();
        }
        public void Button2_Click(object sender, EventArgs e)
        {
            if (bl1.Visible == false)
            {
                bl1.Visible = true; 
            }
            else
            {
                bl1.Visible = false; 
            }
        }
        public void Button3_Click(object sender, EventArgs e)
        {
            bl1.Items.Clear();
        }
    }
}