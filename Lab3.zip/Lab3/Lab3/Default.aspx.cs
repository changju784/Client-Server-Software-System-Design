﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab3
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        void Swap(ref char a, ref char b)
        {
            if (a == b) return;

            var temp = a;
            a = b;
            b = temp;
        }

        void ListallPermute(char[] list, int k, int m, ref int ans, bool eliminate_dup)
        {
            if (k == m)
            {
                if (eliminate_dup)
                {
                    ListItem item = lb1.Items.FindByText(string.Join("", list));
                    if (item != null) { return; }
                }
                lb1.Items.Add(string.Join("", list));
                ans++;
                return;
            }
            else
                for (int i = k; i <= m; i++)
                {
                    Swap(ref list[k], ref list[i]);
                    ListallPermute(list, k + 1, m, ref ans, eliminate_dup);
                    Swap(ref list[k], ref list[i]);
                }
        }
        public void find_anagrams(object sender, EventArgs e)
        {
            lb1.Items.Clear();
            string input = op1.Text;
            op1.Text = "";
            bool eliminate_dup = cb1.Checked ? true : false;
            int ans = 0;
            if (input.Length > 0 && input.Length < 6)
            {
                char[] arr = input.ToCharArray();
                ListallPermute(arr, 0, arr.Length-1, ref ans, eliminate_dup);
                comment.Text = " " + ans + " anagrams found.";
            }
            else
            {
                comment.Text = "Please enter a string from 1 to 6 characters";
                return;
            }
        }


    }
}