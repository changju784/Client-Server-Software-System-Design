﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace aspx1
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void TempConvert(object sender, EventArgs e)
        {
            errorComment.Text = "";
            string aa;
            string bb;
            double f;
            double c;
            try
            {
                aa = op1.Text;
                bb = op2.Text;
                if ((aa == "" && bb =="") || (aa!="" && bb != ""))
                {
                    errorComment.Text = "Enter one value";
                }
                else
                {
                    if (aa == "")
                    {
                        c = Convert.ToDouble(bb);
                        f = (c*9)/5 + 32;
                        f = Math.Round(f, 5);
                        op1.Text = Convert.ToString(f);
                    }
                    else if (bb == "")
                    {
                        f = Convert.ToDouble(aa);
                        c = (f-32)*5/9;
                        c = Math.Round(c, 5);
                        op2.Text = Convert.ToString(c);
                    }
                }

            }
            catch (Exception ex)
            {
                errorComment.Text = "Please enter a correct value";
            }
            //GetTemp.Text = (a + b).ToString();
        }
        protected void TempClear(object sender, EventArgs e)
        {
            op1.Text = "";
            op2.Text = "";
            errorComment.Text = "";
        }
    }
}